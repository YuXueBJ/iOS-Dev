# SmartPush
#### SmartPush,一款IOS苹果推送测试程序,Mac OS下的apns工具APP
#### SmartPush,iOS Push Notification Debug App 

##### 基于PushMeBaby,https://github.com/stefanhafeneger/PushMeBaby 修改,感谢作者

##界面截图
![image](https://raw.githubusercontent.com/shaojiankui/SmartPush/master/demo.png)


##使用方法
####1.使用方法 拖拽或者浏览测试证书 和生产证书到指定输入框
####2.填写对应的device token  (device token 不同环境不同)
####3.填写Payload
####4.选择即将推送的环境
####5.连接推送服务器
####6.发送推送
####7.手机收到推送消息